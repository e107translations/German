<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/12/04 15:30:34
|
|        $Author: yak $
+---------------------------------------------------------------+
*/
define("LAN_THEMEPREF_00", "Markierung");
define("LAN_THEMEPREF_01", "Navbar Anpassung");
define("LAN_THEMEPREF_02", "Registrierung/Anmeldung Platzierung:");
define("LAN_THEMEPREF_03", "Bootswatch Stile:");
define("LAN_THEMEPREF_04", "Seitenname");
define("LAN_THEMEPREF_05", "Seiten-Logo");
define("LAN_THEMEPREF_06", "Logo &amp; Sitenname");
define("LAN_THEMEPREF_07", "Links");
define("LAN_THEMEPREF_08", "Rechts");
define("LAN_THEMEPREF_09", "Oben");
define("LAN_THEMEPREF_10", "Unten");
