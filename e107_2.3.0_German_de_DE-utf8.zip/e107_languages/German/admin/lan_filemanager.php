<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_filemanager.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_filemanager.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("FMLAN_12", "Datei");
define("FMLAN_13", "Dateien");
define("FMLAN_14", "Verzeichnis");
define("FMLAN_15", "Verzeichnisse");
define("FMLAN_16", "Root Verzeichnis");
define("FMLAN_18", "Grösse");
define("FMLAN_19", "Zuletzt modifiziert");
define("FMLAN_21", "Datei Upload in dieses Verzeichnis");
define("FMLAN_22", "Upload.");
define("FMLAN_29", "Pfad");
define("FMLAN_30", "Level höher");
define("FMLAN_31", "Ordner");
define("FMLAN_32", "Verzeichnis auswählen");
define("FMLAN_34", "Gewähltes Verzeichnis");
define("FMLAN_35", "Datei Verzeichnis");
define("FMLAN_38", "Datei erfolgreich verschoben nach");
define("FMLAN_39", "Es ist nicht möglich die Datei zu verschieben nach");
define("FMLAN_40", "Newspost-Images Verzeichnis");
define("FMLAN_43", "Ausgewählte Dateien löschen");
define("FMLAN_46", "Bitte bestätigen Sie die ausgewählte Datei löschen zu wollen.");
define("FMLAN_47", "Benutzer Uploads");
define("FMLAN_48", "Ausgewähltes verschieben nach");
define("FMLAN_49", "Bitte bestätigen Sie, ausgewählte Datei verschieben zu wollen.");
define("FMLAN_50", "Verschieben");
define("FMLAN_51", "Unbekannter Fehler:");


?>