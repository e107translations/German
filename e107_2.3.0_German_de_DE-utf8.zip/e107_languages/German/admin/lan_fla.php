<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_fla.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_fla.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("FLALAN_2", "Es wurden keine fehlerhaften Loginversuche gelogged");
define("FLALAN_3", "Versuch gelöscht");
define("FLALAN_4", "Benutzer die mit falschem Benutzernamen/Passwort Loginversuche unternommen haben");
define("FLALAN_5", "IP(s) verbannt");
define("FLALAN_7", "Daten");
define("FLALAN_8", "IP Adresse/ Host");
define("FLALAN_10", "Lösche / Verbanne markierte Einträge");
define("FLALAN_15", "Die folgende IP Adresse(n) sind auto - gebannt , Benutzer hatte mehr als 10 fehlerhafte Loginversuche");
define("FLALAN_16", "Diese Auto-Verbannungs-Liste löschen");
define("FLALAN_17", "Auto-Verbannungsliste gelöscht");
define("FLALAN_18", "IP-Adresse konnte nicht verbannt werden --IP-- - ist auf der Weissenliste");


?>