<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_updateadmin.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_updateadmin.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Fehler - bitte erneut übertragen");
define("UDALAN_2", "Einstellungen aktualisiert");
define("UDALAN_3", "Einstellungen aktualisiert für");
define("UDALAN_4", "Name");
define("UDALAN_5", "Passwort");
define("UDALAN_6", "Passwort wiederholen");
define("UDALAN_7", "Passwort ändern");
define("UDALAN_8", "Passwort Aktualisierung für");

?>