<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_wmessage.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_wmessage.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("WMLAN_00", "Willkommens Nachricht");
define("WMLAN_05", "Einbetten");
define("WMLAN_06", "Falls markiert, wird der Text innerhalb der Box gerendert");
define("WMLAN_07", "Standard System Einstellungen überschreiben um {WMESSAGE} shortcode zu nutzen:");
define("WMLAN_11", "eingeschlossen mit Karussell");
define("WMLAN_12", "Willkommennachricht Hilfe");
define("WMLAN_13", "Auf dieser Seite können Sie eine Nachricht festlegen, die am oberen Rand Ihrer Vorderseite angezeigt wird, sobald sie aktiviert ist.Sie können eine andere Nachricht für Gäste, registrierte / angemeldeten Mitglieder und Administratoren festlegen.");


?>