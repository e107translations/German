<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/09 18:30:36
|
|        $Author: Killer0561 $
+---------------------------------------------------------------+
*/

define("PHP_LAN_1", "Wenn Sie Curl aktiviert haben, sollten Sie diese Funktion deaktivieren.");
define("PHP_LAN_2", "Dies ist ein Sicherheitsrisiko und wird von e107 nicht benötigt.");
define("PHP_LAN_3", "Auf einem Produktionsserver ist es besser, die Anzeige von Fehlern im Browser zu deaktivieren.");
define("PHP_LAN_4", "Wenn du dies deaktivierst, versteckst du deine PHP-Version von Browsern.");
define("PHP_LAN_5", "Dies ist ein Sicherheitsrisiko und sollte deaktiviert werden.");
define("PHP_LAN_6", "[b]session.save_path[/b] ist nicht beschreibbar! Das kann große Probleme mit Ihrer Website verursachen.");


?>