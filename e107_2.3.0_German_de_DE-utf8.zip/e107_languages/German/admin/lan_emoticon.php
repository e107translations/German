<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_emoticon.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_emoticon.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Smilie Aktivierung");
define("EMOLAN_3", "Smilies");
define("EMOLAN_4", "Smilies aktivieren?");
define("EMOLAN_5", "Bild");
define("EMOLAN_6", "Smilie Code");
define("EMOLAN_7", "Mehrfache Eingaben mit Leerstellen trennen");
define("EMOLAN_11", "Paket aktivieren");
define("EMOLAN_13", "Installierte Pakete");
define("EMOLAN_17", "Sie verwenden im Moment ein Smiliepaket, welches Leerzeichen beinhaltet, die nicht erlaubt sind !");
define("EMOLAN_18", "Korrigieren Sie bitte unten aufgeführte Liste, so dass keine Leerstellen mehr vorhanden sind:");
define("EMOLAN_20", "Ort");
define("EMOLAN_21", "Fehler");
define("EMOLAN_22", "Neues Smilie-Paket gefunden:");
define("EMOLAN_23", "Neues Smilie-xml-Paket gefunden:");
define("EMOLAN_24", "Neues Smilie-php gefunden:");
define("EMOLAN_26", "Paket nochmals scannen");
define("EMOLAN_27", "Es ist ein Fehler aufgetreten:");
define("EMOLAN_28", "XML generieren");
define("EMOLAN_29", "XML Datei erstellt:");
define("EMOLAN_30", "Fehler beim Schreiben der XML Datei");
define("EMOLAN_PAGE_TITLE", "Gefühle");
define("EMOLAN_31", "Gesamte [x] Dateien gefunden");
define("EMOLAN_32", "Unbekanntes Paket entdeckt");
define("EMOLAN_33", "Nicht unterstütztes XML Dateiformat");
define("EMOLAN_34", "Fehlenden Dateien für dieses Paket");
define("EMOLAN_35", "-lösche in Datenbank");
define("EMOLAN_37", "Gefühle nicht gesetzt");
define("EMOLAN_38", "Leerer Gefühlwert");


?>