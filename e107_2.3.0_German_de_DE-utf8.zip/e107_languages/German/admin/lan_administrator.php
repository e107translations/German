<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_administrator.php $ 
|     $Revision: 261 $
|     $Date: 2012-11-25 01:43:48 +0100 (So, 25. Nov 2012) $
|     $Id: lan_administrator.php 261 2012-11-25 00:43:48Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("ADMSLAN_6", "ist der Hauptseiten Administrator und kann nicht gelöscht werden.");
define("ADMSLAN_13", "Angelegte Administratoren");
define("ADMSLAN_16", "Admin Name");
define("ADMSLAN_18", "Rechte");
define("ADMSLAN_21", "Administratorberechtigungen modifizieren");
define("ADMSLAN_25", "Upload /Dateien verwalten");
define("ADMSLAN_27", "Übersicht Link Kategorien");
define("ADMSLAN_41", "Schreibe Artikel");
define("ADMSLAN_42", "Schreibe Berichte");
define("ADMSLAN_52", "Administrator aktualisieren");
define("ADMSLAN_56", "Seiten Administrator");
define("ADMSLAN_58", "Hauptseiten Administrator");
define("ADMSLAN_59", "Admin Status aufheben");
define("ADMSLAN_61", "Administrator gelöscht");
define("ADMSLAN_62", "Plugin Manager");
define("ADMSLAN_71", "Hier klicken um Privilegien anzuzeigen");
define("ADMSLAN_72", "Admin ID: [x] Name: [y] neue Berechtigungen:");
define("ADMSLAN_73", "Admin ID: [x] Name: [y]");
