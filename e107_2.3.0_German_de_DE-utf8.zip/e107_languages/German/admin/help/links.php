<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/help/links.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: links.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
$text = "Geben Sie Ihre Seitenlinks hier ein. Hier eingetragene Links, werden im Hauptnavigationsmenü angezeigt. Für andere Links nutzen Sie bitte das Links Page Plugin.
<br />
<br />
Der Submenügenerator ist nur für e107 DHTML-Menüs sinnvoll. (TreeMenu, UltraTreeMenu, eDynamicMenu, ypSlideMenu...)";
$ns -> tablerender("Links Hilfe", $text);
?>
