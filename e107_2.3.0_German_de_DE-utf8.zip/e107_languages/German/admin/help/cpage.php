<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/help/cpage.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: cpage.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Von dieser Seite aus, können Sie eigene Seiten - eigene Menüs erstellen und mit Ihren eigenen Inhalten füllen.<br /><br />";
// $text .= "Für Näheres besuchen Sie bitte <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a> um einen Einblick in die Features dieser Möglichkeit zu erhalten.";

$ns -> tablerender('Eigene Menüs/Seiten Hilfe', $text);
?>
