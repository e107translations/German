<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/help/download.php $ 
|     $Revision: 156 $
|     $Date: 2011-09-28 19:57:27 +0200 (Mi, 28. Sep 2011) $
|     $Id: download.php 156 2011-09-28 17:57:27Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
$text = "Bitte laden Sie die Dateien in den Ordner ".e_DOWNLOAD.", die Bilder in den Ordner ".e_FILE."downloadimages und die Vorschaubilder (Thumbnails) in den Ordner ".e_FILE."downloadthumbs hoch.
<br /><br />
Um einen Download zu übermitteln, müssen Sie zuerst eine Hauptkategorie erstellen, z.B. Fotos. Dann erstellen Sie eine oder meherer Unterkategorien, wie z.B. JPEG-Bilder, TIFF-Bilder usw. In diese Unterkategorien können Sie dann über 'Download erstellen' Ihre Downloads zur Verfügung stellen.";
$ns -> tablerender("Download Hilfe", $text);
?>
