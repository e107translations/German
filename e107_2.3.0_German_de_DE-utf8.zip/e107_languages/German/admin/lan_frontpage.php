<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_frontpage.php $ 
|     $Revision: 269 $
|     $Date: 2013-03-19 20:26:49 +0100 (Di, 19. Mrz 2013) $
|     $Id: lan_frontpage.php 269 2013-03-19 19:26:49Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_13", "Hauptseiten Einstellungen");
define("FRTLAN_30", "Benutzerdefinierte Seite");
define("FRTLAN_35", "Post-Anmeldeseite");
define("FRTLAN_42", "neue Regel hinzufügen");
define("FRTLAN_43", "Klasse");
define("FRTLAN_46", "bearbeite vorhandene Regel");
define("FRTLAN_49", "Startseite");
define("FRTLAN_51", "Andere");
define("FRTLAN_PAGE_TITLE", "Hauptseite");
define("FRTLAN_56", "doppelte Definition für Klasse:");
define("FRTLAN_57", "Software Fehler");
define("FRTLAN_61", "Auswahl");


?>