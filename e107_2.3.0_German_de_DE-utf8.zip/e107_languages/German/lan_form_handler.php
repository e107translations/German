<?php
	/**
	 * e107 website system
	 *
	 * Copyright (C) 2008-2017 e107 Inc (e107.org)
	 * Released under the terms and conditions of the
	 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
	 *
	 */
define("LAN_EFORM_001", "Klicken Sie auf den Avatar, um ihn zu ändern");
define("LAN_EFORM_002", "Wähle Avatar");
define("LAN_EFORM_003", "ODER");
define("LAN_EFORM_004", "Wähle diesen Avatar");
define("LAN_EFORM_005", "Keine Avatare verfügbar");
define("LAN_EFORM_006", "Hinweis für Admins:[br]Der Ordner[b][x][/b] ist leer.[br]Laden Sie einige Standard Avatare Bilder in diesen Ordner für Benutzer, um Avatare auszuwählen.");
define("LAN_EFORM_007", "Medien Manager");
define("LAN_EFORM_008", "Wählen Sie die anzuzeigenden Spalten aus");
define("LAN_EFORM_009", "Spalten anzeigen");
define("LAN_EFORM_010", "Schnellansicht");
define("LAN_EFORM_011", "Gehen Sie zum Benutzerprofil");
define("LAN_EFORM_012", "Mehrsprachiges Feld");
define("LAN_EFORM_013", "Zur Liste gehen");
define("LAN_EFORM_014", "Ein anderes erstellen");
define("LAN_EFORM_015", "Aktuelles bearbeiten");
define("LAN_EFORM_016", "Nach abschicken:");


?>