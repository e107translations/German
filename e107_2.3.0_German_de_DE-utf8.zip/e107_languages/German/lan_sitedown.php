<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_sitedown.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_sitedown.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vorübergehend geschlossen ");
define("LAN_SITEDOWN_00", "ist vorübergehend geschlossen");
define("LAN_SITEDOWN_01", "Diese Seite wurde vorübergehend geschlossen, um wichtige Wartungsarbeiten durchzuführen. Das sollte nicht lange dauern. Bitte kommen Sie bald wieder. Wir bitten um Entschuldigung für diesen Umstand.");
?>