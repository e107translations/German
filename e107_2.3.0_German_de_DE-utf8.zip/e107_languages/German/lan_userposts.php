<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_userposts.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_userposts.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Benutzer Einträge");
define("UP_LAN_0", "Alle Forenbeiträge für [x]");
define("UP_LAN_1", "Alle Kommentare zu [x]");
define("UP_LAN_2", "Thread");
define("UP_LAN_3", "Ansichten");
define("UP_LAN_4", "Antworten");
define("UP_LAN_5", "Letzter Eintrag");
define("UP_LAN_6", "Themen");
define("UP_LAN_7", "Keine Kommentare");
define("UP_LAN_8", "Keine Einträge");
define("UP_LAN_9", " am");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Geschrieben am:");
define("UP_LAN_12", "Suche");
define("UP_LAN_14", "Forum Beiträge");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP Adresse");
