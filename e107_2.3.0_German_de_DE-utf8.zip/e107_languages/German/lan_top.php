<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_top.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_top.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "Top Forum Schreiber");
define("TOP_LAN_1", "Benutzer Name");
define("TOP_LAN_2", "Einträge");
define("TOP_LAN_3", "Top Kommentare Schreiber");
define("TOP_LAN_4", "Kommentare");
define("TOP_LAN_5", "Top Chatbox Schreiber");
define("TOP_LAN_6", "Seitenbewertung");
define("LAN_1", "Thema");
define("LAN_2", "Schreiber");
define("LAN_3", "Ansichten");
define("LAN_4", "Antworten");
define("LAN_5", "Letzter Eintrag");
define("LAN_6", "Themen");
define("LAN_7", "Meist aktiven Threads");
define("LAN_8", "Top Schreiber");


?>