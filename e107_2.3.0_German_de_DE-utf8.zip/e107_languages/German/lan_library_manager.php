<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/05/17 09:48:22
|
|        $Author: Admin $
+---------------------------------------------------------------+
*/
define("LAN_LIBRARY_MANAGER_01", "Das [x] Bibliothek, die die [y] benötigt, ist nicht installiert ist.");
define("LAN_LIBRARY_MANAGER_02", "Die Version [x] der [y] Bibliothek ist nicht kompatibel mit dem [z] Bibliothek.");
define("LAN_LIBRARY_MANAGER_03", "Die [x] Bibliothek nicht gefunden werden konnte.");
define("LAN_LIBRARY_MANAGER_04", "Die Version des [x] Bibliothek nicht nachgewiesen werden konnte.");
define("LAN_LIBRARY_MANAGER_05", "Die installierte Version [x] der [y] Bibliothek wird nicht unterstützt.");
define("LAN_LIBRARY_MANAGER_06", "Die [x] Variante der [y] Bibliothek nicht gefunden werden konnte .");
define("LAN_LIBRARY_MANAGER_07", "fehlende Abhängigkeit");
define("LAN_LIBRARY_MANAGER_08", "unvereinbar Abhängigkeit");
define("LAN_LIBRARY_MANAGER_10", "nicht erkannt");
define("LAN_LIBRARY_MANAGER_11", "nicht unterstützt");
define("LAN_LIBRARY_MANAGER_13", "Bibliothek");
define("LAN_LIBRARY_MANAGER_21", "Anbieter");
define("LAN_LIBRARY_MANAGER_25", "Bibliotheken von Drittanbietern");
define("LAN_LIBRARY_MANAGER_27", "Maschinenname: [x]");
define("LAN_LIBRARY_MANAGER_28", "Bibliothekspfad: [x]");
define("LAN_LIBRARY_MANAGER_29", "Bibliothekspfad");
define("LAN_LIBRARY_MANAGER_30", "CDN Einstellungen");
define("LAN_LIBRARY_MANAGER_31", "Verwenden Sie CDN für Kernbibliotheken");
define("LAN_LIBRARY_MANAGER_32", "CDN Anbieter");


?>