<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_print.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_print.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Druckerfreundlich"); }

define("LAN_PRINT_86", "Kategorie:");
define("LAN_PRINT_87", "von ");
define("LAN_PRINT_94", "Eintrag von");
define("LAN_PRINT_135", "News: ");
define("LAN_PRINT_303", "Diese News sind von ");
define("LAN_PRINT_304", "Artikel Titel: ");
define("LAN_PRINT_305", "Untertitel: ");
define("LAN_PRINT_306", "Dieser Artikel ist von ");
define("LAN_PRINT_307", "Diese Seite drucken");

define("LAN_PRINT_1", "Druckerfreundlich");

?>