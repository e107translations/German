<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_page.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_page.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("LAN_PAGE_1", "Seitenauflistung ist abgestellt");
define("LAN_PAGE_2", "Es gibt keine Seiten");
define("LAN_PAGE_3", "Angeforderte Seite besteht nicht");
define("LAN_PAGE_4", "Bewerten Sie diese Seite");
define("LAN_PAGE_5", "Danke für das Bewerten dieser Seite");
define("LAN_PAGE_6", "Sie haben keine Berechtigung diese Seite anzusehen");
define("LAN_PAGE_7", "Falsches Passwort");
define("LAN_PAGE_8", "Passwortgeschützte Seite");
define("LAN_PAGE_9", "Passwort");
define("LAN_PAGE_10", "Übermitteln");
define("LAN_PAGE_11", "Seiten Auflistung");
define("LAN_PAGE_12", "Ungültige Seite");
define("LAN_PAGE_13", "Seite");
define("LAN_PAGE_14", "andere Artikel");
define("LAN_PAGE_15", "Artikel");
define("LAN_PAGE_16", "Es sind keine Kapitel in diesen Buch");


?>