<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_notify.php $ 
|     $Revision: 254 $
|     $Date: 2012-11-24 23:36:50 +0100 (Sa, 24. Nov 2012) $
|     $Id: lan_notify.php 254 2012-11-24 22:36:50Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Benutzer Registrierung");
define("NT_LAN_UV_1", "Benutzer Registrierung verifiziert");
define("NT_LAN_UV_2", "Benutzer Session String");
define("NT_LAN_UV_3", "Benutzer Login Name:");
define("NT_LAN_UV_4", "Benutzer IP:");
define("NT_LAN_LI_1", "Benutzer eingelogged");
define("NT_LAN_LO_1", "Benutzer ausgelogged");
define("NT_LAN_LO_2", " aus der Seite ausgelogged");
define("NT_LAN_FL_1", "Flood Bannung");
define("NT_LAN_FL_2", "Ip Adresse wurde wegen flooding gebannt - Es gab zu viele Anfragen mit einer und der selben IP Adresse in der in den Voreinstellungen gesetzten Konfiguration -");
define("NT_LAN_SN_1", "Newseintrag übermittelt");
define("NT_LAN_ML_1", "Massen E-mail wurde komplett gesendet.");
define("NT_LAN_NU_1", "Aktualisiert");
define("NT_LAN_ND_1", "Newseintrag gelöscht");
define("NT_LAN_ND_2", "Newseintrags Id gelöscht");


?>