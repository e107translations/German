<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_online.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_online.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Gäste:");
define("ONLINE_EL2", "Mitglieder:");
define("ONLINE_EL3", "Auf dieser seite:");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Mitglieder");
define("ONLINE_EL6", "Neuestes Mitglied");
define("ONLINE_EL7", "befindet sich auf");
define("ONLINE_EL8", "am meisten online:");
define("ONLINE_EL9", "am");
define("ONLINE_EL10", "Mitglieds Name");
define("ONLINE_EL11", "Befindet sich auf Seite");
define("ONLINE_EL12", "Antworten");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Thema");
define("ONLINE_EL15", "Seite");
define("ONLINE_EL16", "Information nicht vorhanden");
define("CLASSRESTRICTED", "Benutzerklassen beschränkte Seite");
define("CHAT", "Chat");
define("DOWNLOAD", "Downloads");
define("EMAIL", "email.php");
define("FORUM", "Haupt Forum Index");
define("LINKS", "Links");
define("NEWS", "News");
define("OLDPOLLS", "Alte Umfragen");
define("POLLCOMMENT", "Umfrage");
define("PRINTPAGE", "Drucken");
define("LOGIN", "Anmelden");
define("SEARCH", "Suchen");
define("STATS", "Seitenstatistik");
define("SUBMITNEWS", "News eintragen");
define("UPLOAD", "Uploads");
define("USERPAGE", "Mitglieder Profile");
define("USERSETTINGS", "Benutzer Einstellungen");
define("ONLINE", "Benutzer Online");
define("LISTNEW", "News Einträge auflisten");
define("USERPOSTS", "Benutzer Einträge");
define("SUBCONTENT", "Übermittle Inhalt");
define("TOP", "Top Posters/Meist aktive Themen");
define("ADMINAREA", "Adminbereich");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Ereignis Liste");
define("CALENDAR", "Ereignis Kalender");
define("FAQ", "FAQ");
define("PM", "Private Nachrichten");
define("SURVEY", "Umfragen");
define("ARTICLE", "Artikel");
define("CONTENT", "Inhaltsseiten");
define("REVIEW", "Bericht");
define("OTHER", "andere Seite");


?>