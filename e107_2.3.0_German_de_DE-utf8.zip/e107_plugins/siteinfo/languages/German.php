<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/siteinfo/languages/German.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/07 14:13:20 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("COMPLIANCE_L1", "W3C Einhaltung");
define("SITEBUTTON_MENU_L1", "Link zu uns");
define("POWEREDBY_L1", "unterstützt von");
define("COUNTER_L1", "Admin besuche werden nicht gezählt.");
define("COUNTER_L2", "Diese Seite heute ...");
define("COUNTER_L3", "Gesamt");
define("COUNTER_L4", "Diese Seite überhaupt ...");
define("COUNTER_L5", "einzigartig");
define("COUNTER_L6", "Seite");
define("COUNTER_L7", "Ausgabe");
define("COUNTER_L8", "Admin Nachricht : <b> Statistik Protokollierung ist deaktiviert </ b><br /> Zum Aktivieren der Statistikaufzeichnung -Plugin von Ihrem <a href='".e_ADMIN."plugin.php'>müssen Sie im Plugin-Manager installieren</a> dann aktivieren Sie es in der<a href='".e_PLUGIN."log/admin_config.php'> Konfiguration</a> .");


?>