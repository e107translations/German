<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/poll/languages/German_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/10 22:02:01 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_POLL_NAME", "Umfragen");
define("LAN_PLUGIN_POLL_DESCRIPTION", "Dieses Plugin ermöglicht es Ihnen Umfragen/Abstimmungen zu schalten, entweder im Menü oder im Forum.");


?>