<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/poll/languages/German.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/10 21:06:35 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("POLLAN_3", "Umfrage Fragestellung");
define("POLLAN_4", "Umfrage Optionen");
define("POLLAN_12", "Ergebnisse anzeigen");
define("POLLAN_13", "nach Abstimmung");
define("POLLAN_14", "mit Klick auf den Ergebnis Link - Kommentare müssen eingeschaltet sein , um diese Option zu nutzen.");
define("POLLAN_15", "Erlaube bei dieser Umfrage abzustimmen");
define("POLLAN_16", "Abstimmung Speichermethode");
define("POLLAN_17", "Cookie:");
define("POLLAN_19", "BenutzerID (nur Mitglieder können abstimmen");
define("POLLAN_28", "Vorherige Umfragen");
define("POLLAN_31", "Abstimmungen");
define("POLLAN_40", "Hier klicken um Ergebnisse anzuzeigen");
define("POLLAN_41", "Es können nur Mitglieder an Umfragen teilnehmen");
define("POLLAN_42", "Es können nur Administratoren an Umfragen teilnehmen");
define("POLLAN_43", "Sie haben keine Berechtigung in dieser Umfrage abzustimmen");
define("POLLAN_50", "Aktiv von [x] bis [y]");
define("LAN_FORUM_3029", "Wenn Sie nicht möchten, dass eine Umfrage zu Ihrem Thema hinzufügt werden soll , lassen Sie die Felder leer .");


?>