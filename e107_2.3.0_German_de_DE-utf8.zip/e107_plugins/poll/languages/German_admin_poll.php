<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/poll/languages/German_admin_poll.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/10 21:54:37 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("POLL_ADLAN03", "Umfragen konfigurieren");
define("POLL_ADLAN04", "Das Umfrageplugin wurde erfolgreich installiert. Gehen Sie in Ihren Menübereich um es zu aktivieren, und klicken Sie im Pluginbereich Ihrer Administration auf das Umfrage Ikon um das Plugin zu konfigurieren und/oder neue Umfragen zu schalten.");
define("POLL_ADLAN05", "Haupt - Umfrage");
define("POLL_ADLAN06", "Forum Thema:");
define("POLL_ADLAN07", "Typ");
define("POLLAN_MENU_CAPTION", "Umfrage");
define("POLLAN_7", "Keine Umfragen bis jetzt.");
define("LAN_AL_POLL_01", "Umfrage gelöscht");
define("LAN_AL_POLL_02", "Umfrage aktualisiert");
define("LAN_AL_POLL_03", "Umfrage hinzugefügt");
define("LAN_AL_POLL_04", "");
define("LAN_AL_POLL_05", "");


?>