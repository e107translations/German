<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * e107 Main
 *
 * $Source: /cvs_backup/e107_0.8/e107_plugins/online/languages/English.php,v $
 * $Revision$
 * $Date$
 * $Author$
*/
define("LAN_LASTSEEN_1", "zuletzt gesehen Menü");
define("LAN_ONLINE_TRACKING_MESSAGE", "Online Benutzerverfolgung ist derzeit deaktiviert , bitte aktiviere es [link=".e_ADMIN."users.php?options]here[/link][br]");
define("LAN_ONLINE_1", "Gäste:");
define("LAN_ONLINE_2", "Mitglieder:");
define("LAN_ONLINE_3", "Auf dieser Seite:");
define("LAN_ONLINE_4", "Online");
define("LAN_ONLINE_5", "");
define("LAN_ONLINE_6", "Neuestes Mitglied:");
define("LAN_ONLINE_7", "angesehen");
define("LAN_ONLINE_8", "Online Rekord:");
define("LAN_ONLINE_9", "am ");
define("LAN_ONLINE_10", "Online Menü");
define("LAN_ONLINE_11", "Registrierte Mitglieder insgesamt:");
define("LAN_ONLINE_ADMIN_1", "zuletzt gesehen Menü");
define("LAN_ONLINE_ADMIN_2", "zuletzt gesehen Menü - Untertitel");
define("LAN_ONLINE_ADMIN_3", "Anzahl der Protokolle zum amzeigen");
define("LAN_ONLINE_ADMIN_4", "Online Menü");
define("LAN_ONLINE_ADMIN_5", "Online Menü - Untertitel");
define("LAN_ONLINE_ADMIN_6", "Liste der Mitglieder Online anzeigen?");
define("LAN_ONLINE_ADMIN_7", "erweiterte Mitgliederliste Online anzeigen?");
define("LAN_ONLINE_ADMIN_8", "Zeigt eine mit Komma getrennte Liste der Mitglieder.");
define("LAN_ONLINE_ADMIN_9", "Zeigt eine Liste der Mitglieder einer Seite angezeigt wird.");
define("LAN_ONLINE_ADMIN_10", "Gäste online anzeigen.");


?>