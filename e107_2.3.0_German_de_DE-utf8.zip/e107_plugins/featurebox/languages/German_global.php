<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/featurebox/languages/German_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/08 10:28:53 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_FEATUREBOX_NAME", "Feature Box");
define("LAN_PLUGIN_FEATUREBOX_DESCRIPTION", "Zeigt einen animierten Bereich auf dem oberen Rand der Seite mit News - Artikel und andere Inhalte, über den verfügen Sie möchten.");
define("LAN_PLUGIN_FEATUREBOX_BATCH", "Featurebox Eintrag erstellen.");
define("LAN_PLUGIN_FEATUREBOX_RSSFEED", "Dies ist der rss-Feed für die Featurebox-Einträge.");
