<?php
/*
* Copyright (c) e107 Inc 2009 - e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
* $Id$
*
* Featurebox back-end language defines
*/
define("FBLAN_08", "Textnachricht");
define("FBLAN_12", "Modus");
define("FBLAN_13", "Nachrichten nach dem Zufallsprinzip drehen");
define("FBLAN_14", "zeige nur diese Nachricht");
define("FBLAN_22", "Render-Typ");
define("FBLAN_23", "Im Themenrahmen");
define("FBLAN_24", "einfach");
define("FBLAN_25", "Es sind keine Featurebox-Elemente der [x] Vorlage zugeordnet.");
define("FBLAN_26", "Bild/Video");
define("FBLAN_27", "Link zum Bild");
define("FBLAN_28", "Featurebox Menü Kategorie");
define("FBLAN_29", "Kategorie für das Featurebox-Menü verwenden");
define("FBLAN_30", "Kategorie Vorlage");
define("FBLAN_31", "Zufällig");
define("FBLAN_32", "Parameter (optional)");
define("FBLAN_33", "Optionale Javascript-Parameter (Änderungen vorbehalten)");
define("FBLAN_34", "Nicht zugewiesen");
define("FBLAN_35", "Karussell");
define("FBLAN_36", "Tabs");
