<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|
*/

define("CM_L1", "Keine Kommentare bis jetzt.");
define("CM_L2", "");
define("CM_L3", "Überschrift");
define("CM_L4", "Anzahl der Kommentare die angezeigt werden sollen?");
define("CM_L5", "Anzahl der Zeichen die angezeigt werden sollen?");
define("CM_L6", "Postfix für zu lange Kommentare?");
define("CM_L7", "Den orginalen Newstitel im Menü anzeigen?");
define("CM_L8", "Neue Kommentare Menü Konfiguration");
//define("CM_L10", "Kommentarmenü Konfiguration gespeichert");
define("CM_L11", "am");
define("CM_L12", "Re:");
define("CM_L13", "Geschrieben von");


?>