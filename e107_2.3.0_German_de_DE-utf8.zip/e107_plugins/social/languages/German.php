<?php
define("SO_LAN_1", "News and comments information sharing in social systems.<br />Add {SOCIAL} shortcode to your theme.php (newssection).");
define("SO_LAN_2", "Plugin has been successfully installed! Add {SOCIAL} shortcode to your theme.php (newssection).");
define("SO_LAN_3", "Deinstallation erfolgreich!");
define("SO_LAN_4", "Upgrade erfolgreich!");
define("SO_LAN_5", "News teilen:");
define("SO_LAN_6", "Teilen auf Facebook");
define("SO_LAN_7", "Teilen auf Myspace");
define("SO_LAN_8", "Teilen auf Google Buzz");
define("SO_LAN_9", "Digg This");
define("SO_LAN_10", "Teilen auf Delicious");
define("SO_LAN_11", "Teilen auf Reddit");
define("SO_LAN_12", "Teilen auf Twitter");
define("SO_LAN_13", "Teilen auf StumbleUpon");
?>