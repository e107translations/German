<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/12/03 13:07:17
|
|        $Author: yak $
+---------------------------------------------------------------+
*/
define("LAN_SOCIAL_000", "Teilen auf [x]");
define("LAN_SOCIAL_001", "Like auf [x]");
define("LAN_SOCIAL_002", "E-Mail an jemanden");
define("LAN_SOCIAL_003", "+1 auf Google");
define("LAN_SOCIAL_004", "hinzufügen von [x]");
define("LAN_SOCIAL_005", "Überprüfe diesen Link:");
define("LAN_SOCIAL_100", "Der Feed kann nicht angezeigt werden.Facebook-App-ID wurde in den Einstellungen nicht definiert.");
define("LAN_SOCIAL_200", "Der Feed kann nicht angezeigt werden. Twitter-URL wurde in den Einstellungen nicht definiert.");
define("LAN_SOCIAL_201", "Tweets von");
define("LAN_SOCIAL_202", "Auf Twitter schreiben");
define("LAN_SOCIAL_203", "Art deines Tweet hier.");
define("LAN_SOCIAL_204", "teilen");
define("LAN_SOCIAL_205", "Kann Kommentare nicht rendern. Fehlende Facebook-AppID.");
define("LAN_SOCIAL_WARNING", "Facebook Kommentare erfordert, dass Sie eine Facebook-App-ID haben.Siehe 'social login' Bereich in den Admin-Einstellungen, um einen hinzuzufügen.");


?>