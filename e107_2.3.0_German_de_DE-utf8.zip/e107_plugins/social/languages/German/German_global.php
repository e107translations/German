<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/12/03 13:20:11
|
|        $Author: yak $
+---------------------------------------------------------------+
*/
define("LAN_SOCIAL_ADMIN_SUMM", "Fügt Facebook, Twitter und andere Social-Media-Widgets zu e107 hinzu.");
define("LAN_PLUGIN_SOCIAL_DESCR", "Fügt Optionen hinzu, die e107 Kommentar-Engine durch Facebook zu ersetzen.Fügen Sie Twitter Feeds zu Ihrer Website hinzu. usw.");
define("LAN_PLUGIN_SOCIAL_SIGNIN", "Anmelden mit:");
define("LAN_PLUGIN_SOCIAL_XUP_SIGNUP", "Anmelden mit deinen [x] Konto");
define("LAN_PLUGIN_SOCIAL_XUP_REG", "Registrieren mit deinen [x] Konto");
define("LAN_PLUGIN_SOCIAL_NAME", "Soziale");
