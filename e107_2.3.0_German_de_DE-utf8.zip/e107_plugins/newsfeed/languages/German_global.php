<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/03/15 10:28:09
|
|        $Author: Admin $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_NEWSFEEDS_NAME", "Newsfeeds");
define("LAN_PLUGIN_NEWSFEEDS_DESCRIPTION", "Mit diesem Plugin können Sie Newsfeeds von anderen Webseiten auf Ihrer Seite einspeisen, abhängig von Ihren Voreinstellungen.");


?>