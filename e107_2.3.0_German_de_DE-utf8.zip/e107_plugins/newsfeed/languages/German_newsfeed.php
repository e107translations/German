<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * Plugin - newsfeeds
 *
 * $URL$
 * $Id$
 *
*/
define("NFLAN_29", "vorhandene Newsfeed");
define("NFLAN_31", "zurück zur Newsfeedliste");
define("NFLAN_33", "Datum der Veröffentlichung:");
define("NFLAN_34", "unbekannt");
define("NFLAN_38", "Schlagzeilen");
define("NFLAN_39", "Details:");
define("NFLAN_48", "Ausserstande die Rohdaten in der Datenbank zu speichern");


?>