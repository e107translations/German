<?php

define("LAN_PLUGIN_NEWSLETTER_NAME", "Newsletter");
define("LAN_PLUGIN_NEWSLETTER_DESCRIPTION", "Bietet eine schnellen und einfachen Weg zum versenden von Newslettern.");

?>