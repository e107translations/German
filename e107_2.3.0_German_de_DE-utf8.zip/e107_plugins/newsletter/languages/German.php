<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * Plugin - newsfeeds
 *
 * $Source: /cvs_backup/e107_0.8/e107_plugins/newsletter/languages/English.php,v $
 * $Revision$
 * $Date$
 * $Author$
 *
*/
define("NLLAN_MENU_CAPTION", "Newsletter");
define("NLLAN_48", "Sie haben diesem Newsletter abonniert - Wenn Sie den Newsletter abbestellen möchten, klicken Sie bitte unten auf den Button.");
define("NLLAN_49", "Sind Sie sicher, dass Sie diesen Newsletter nicht mehr erhalten wollen?");
define("NLLAN_50", "Click button to subscribe ( your subscription address is");
define("NLLAN_51", "abbestellen");
define("NLLAN_52", "abonnieren");
define("NLLAN_53", "Sind Sie sicher, dass Sie diesen Newsletter abonnieren möchten?");
define("NLLAN_67", "Archivübersicht");
define("NLLAN_68", "Ungültiger Parameter definiert");
define("NLLAN_69", "Keine Newsletter zum senden verfügbar.");
define("NLLAN_70", "Ausgewählte Newsletter existiert nicht");
define("NLLAN_72", "zeige Archive");
define("NLLAN_73", "Gebe eine E-Mail Adresse ein");


?>