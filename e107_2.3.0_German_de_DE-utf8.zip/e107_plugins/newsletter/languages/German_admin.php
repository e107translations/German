<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2013 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * Plugin - Newsletter 
 *
*/
define("NLLAN_04", "Das Newsletter -Plugin wurde erfolgreich installiert.Zum konfigurieren, gehen Sie zu Ihrer Hauptadminseite und klicken Sie auf 'Newsletter' in den Plugin-Bereich.");
define("NLLAN_05", "keine Newsletters definiert zurzeit.");
define("NLLAN_07", "Abonnenten");
define("NLLAN_10", "vorhandene Newsletters");
define("NLLAN_11", "kein Newsletter Ausgaben zurzeit vorhanden.");
define("NLLAN_12", "Ausgabe");
define("NLLAN_13", "[ Stammverzeichnis ID ] Betreff/Titel");
define("NLLAN_14", "absenden?");
define("NLLAN_17", "Noch nicht gesendet - klick zum senden");
define("NLLAN_18", "Sind Sie sicher, dass Sie dieses Ausgabe an den Abonnent versenden wollen?");
define("NLLAN_19", "Sind Sie sicher, dass Sie diesen Newsletter Ausgabe löschen möchten?");
define("NLLAN_20", "Vorhandene Ausgaben");
define("NLLAN_23", "Kopfzeile");
define("NLLAN_24", "Fußzeile");
define("NLLAN_30", "Newsletter");
define("NLLAN_31", "Betreff/Titel");
define("NLLAN_32", "Auagabenummer");
define("NLLAN_33", "Text");
define("NLLAN_36", "Newsletter Ausgaben aktualisieren");
define("NLLAN_37", "Newsletter Ausgabe erstellen");
define("NLLAN_39", "Newsletter Ausgabe wurde in der Datenbank gespeichert - zum senden, klicke den  Veröffentlich Ausgabe Button im Optionen Menü.");
define("NLLAN_40", "abgesendete Email wurden der Warteschlange hinzugefügt - Ausgabe senden zum [x] Abonnent(en).");
define("NLLAN_41", "kein Abonnente gefunden - E-mail abgebrochen");
define("NLLAN_44", "Newsletter erste Seite");
define("NLLAN_45", "Newsletter erstellen");
define("NLLAN_46", "Email absenden erstellen");
define("NLLAN_47", "Newsletter Optionen");
define("NLLAN_48", "Newsletter Abonnenten");
define("NLLAN_49", "Newsletter:");
define("NLLAN_54", "absenden");
define("NLLAN_56", "Newsletter ID ist nicht vorhanden");
define("NLLAN_62", "Benutzer ist verbannt! (oder nichtt vollständig Registriert)");
define("NLLAN_63", "gesammte Abonnenten");
define("NLLAN_64", "zurück zur Newsletter Startseite");
define("NLLAN_65", "Abonnentenübersicht Newsletter ID");
define("NLLAN_66", "Ihr Newsletter Abonnentenliste wurde bereinigt.");
