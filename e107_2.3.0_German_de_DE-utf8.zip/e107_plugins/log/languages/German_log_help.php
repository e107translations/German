<?php
/* e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 *
 *
 * $Source: /cvs_backup/e107_0.8/e107_plugins/log/languages/English_log_help.php,v $
 * $Revision$
 * $Date$
 * $Author$
 */
define("LAN_STAT_HELP_01", "Statistik Protokollierung");
define("LAN_STAT_HELP_02", "Mit dieser Option werden historische Daten aus der Datenbank gelöscht.Es wirkt sich nicht auf die \"alle Zeiten\" Zahlen aus. <br /> <br /> 
Vorsicht! Nach dem Löschen können diese Daten nicht wiederhergestellt werden. Sichern Sie und / oder exportieren Sie die Daten, die Sie zuerst benötigen.");
define("LAN_STAT_HELP_03", "Mit dieser Option können Sie die Daten einer bestimmten Webseite-Seite löschen.");
define("LAN_STAT_HELP_04", "Diese Option ermöglicht den Export von Statistik Daten im CSV-Format.Dieses kann in viele andere Anwendungen für ausführliche Analyse importiert werden.Weitere Informationen finden Sie auf der  Wiki-Seite des Statistik Protokolls");
define("LAN_STAT_HELP_05", "<b> Protokollierung aktivieren </ b><br /> Keine Protokollierung erfolgt, wenn deaktiviert <br /><br/><b>Stats Seiten Zugriff  </ b><br />Bestimmt, wer die Websitestatistik sehen kann <br /><br /><b> zählt Admin Besuche </ b><br />Häufige Besuche durch die Admins können Seitestatistiken verzerren, so dass Sie sie ausschließen können. <br /><br /><b> Maximale Datensätze zur Anzeige ...</ b><br /> Setzt die Anzahl der \ 'letzten Besucher \' beibehalten <br/><b> Statistikkarten </ b><br /> Bestimmt, welche Informationen protokolliert werden.Die Erfassung monatlicher Daten nimmt mehr Speicherplatz in der Datenbank auf und ermöglicht eine bessere Sichtbarkeit.Wenn monatliche Statistiken gesammelt werden, können Sie festlegen, ob nur der aktuelle Monat oder der aktuelle Monat und der vorhergehende Monat angezeigt werden<br /><br /><b> Stats zurücksetzen </ b> <br /> Löscht die ausgewählten Allzeitdaten (bis zum Ende von gestern) auf Null.Löschen Sie die Dateien des Protokolls * .php in dem Log / Logs-Plugin-Verzeichnis , um auch heute die Daten zu löschen<br /><br />");
define("LAN_STAT_HELP_06", "");


?>