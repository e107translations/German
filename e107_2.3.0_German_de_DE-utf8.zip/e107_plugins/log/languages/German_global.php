<?php

define("LAN_PLUGIN_LOG_NAME",			"Seitenstatistik");
define("LAN_PLUGIN_LOG_DESCRIPTION", 	"Dieses Plugin zцєhlt alle Besuche auf Ihrer Seite, und erzeugt verschiedenste Statistiken basierend auf den erhaltenen Informationen. ");
define("LAN_PLUGIN_LOG_CONFIGURE",		"Statistiken Logging konfigurieren"); 
define("LAN_PLUGIN_LOG_LINK", 			"Statistik");

?>