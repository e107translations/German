<?php

// Messages for log entries
define("LAN_AL_STAT_01", "Statistik zurückgesetzt.");
define("LAN_AL_STAT_02", "Statistik - Einstellungen wurden geändert.");
define("LAN_AL_STAT_03", "Statistik - Seiten wurden entfernt.");
define("LAN_AL_STAT_04", "Statistik - Historischedaten wurden entfernt.");
// define("LAN_AL_STAT_05", "");
// define("LAN_AL_STAT_06", "");
// define("LAN_AL_STAT_07", "");