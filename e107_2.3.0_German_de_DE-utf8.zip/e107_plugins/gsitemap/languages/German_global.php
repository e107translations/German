<?php

define("LAN_PLUGIN_GSITEMAP_NAME", "Google Kartebseite");
define("LAN_PLUGIN_GSITEMAP_DESCRIPTION", "Generiert ein Google Kartenseite.");

?>