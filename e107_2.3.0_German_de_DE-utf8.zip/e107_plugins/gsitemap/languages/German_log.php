<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/03/10 11:45:30
|
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_AL_GSMAP_01", "Importiere Seitenlinks");
define("LAN_AL_GSMAP_02", "Sitemap Link wurde gelöscht.");
define("LAN_AL_GSMAP_03", "Sitemap Link wurde hinzugefügt");
define("LAN_AL_GSMAP_04", "Sitemap Link wurde aktuallisiert");


?>