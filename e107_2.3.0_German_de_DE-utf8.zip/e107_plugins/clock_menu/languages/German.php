<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/clock_menu/languages/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define('CLOCK_MENU_L1','Clock Menü Konfiguration gespeichert');
define('CLOCK_MENU_L2','Bezeichnung');
define('CLOCK_MENU_L3','Menüeinstellungen aktuallisieren');
define('CLOCK_MENU_L4','Clock Menü Einstellungen');
define('CLOCK_MENU_L5','Montag,');
define('CLOCK_MENU_L6','Dienstag,');
define('CLOCK_MENU_L7','Mittwoch,');
define('CLOCK_MENU_L8','Donnerstag,');
define('CLOCK_MENU_L9','Freitag,');
define('CLOCK_MENU_L10','Samstag,');
define('CLOCK_MENU_L11','Sonntag,');
define('CLOCK_MENU_L12','Januar');
define('CLOCK_MENU_L13','Februar');
define('CLOCK_MENU_L14','März');
define('CLOCK_MENU_L15','April');
define('CLOCK_MENU_L16','Mai');
define('CLOCK_MENU_L17','Juni');
define('CLOCK_MENU_L18','Juli');
define('CLOCK_MENU_L19','August');
define('CLOCK_MENU_L20','September');
define('CLOCK_MENU_L21','Oktober');
define('CLOCK_MENU_L22','November');
define('CLOCK_MENU_L23','Dezember');
define('CLOCK_MENU_L24','');

?>