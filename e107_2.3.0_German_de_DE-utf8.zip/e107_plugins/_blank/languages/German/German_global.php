<?php

 // Always use the format LAN_PLUGIN_{FOLDER}_{TYPE} to prevent conflicts. In this case "_BLANK" is the folder. 
// This should contain the LANs used in the plugin.xml file. 

define("LAN_PLUGIN__BLANK_NAME", "Leeres Plugin");
define("LAN_PLUGIN__BLANK_DIZ",  "Ein leeres Plugin um ihnen zu helfen beim starten der Plugin Entwicklung. Mehr Details können hier hinzugefügt werden."); 
define("LAN_PLUGIN__BLANK_LINK", "Lerrer Link");

?>