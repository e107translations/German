<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_PM_ADM_01", "PM: Standard Prefs verwendet");
define("LAN_AL_PM_ADM_02", "PM: Prefs aktualisiert");
define("LAN_AL_PM_ADM_03", "PM: DB-Wartung abgeschlossen");
define("LAN_AL_PM_ADM_04", "PM: DB-Wartung gestartet");
define("LAN_AL_PM_ADM_05", "PM: Limit hinzugefügt");
define("LAN_AL_PM_ADM_06", "PM: Limit aktualisiert");
define("LAN_AL_PM_ADM_07", "PM: Limit gelöscht");
define("LAN_AL_PM_ADM_08", "PM: Fehler beim Erstellen einer Grenzwert-Daten");
define("LAN_AL_PM_ADM_09", "PM: Fehler beim Aktualisieren der Daten begrenzen");
define("LAN_AL_PM_ADM_10", "PM: Fehler beim Löschen der Daten begrenzen");
