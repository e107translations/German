<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/12/01 13:12:59
|
|        $Author: Killer0561 $
+---------------------------------------------------------------+
*/

define("LAN_EC_PM_04", "PM-Handler");
define("LAN_EC_PM_05", "Großen Prozess sendet der PMs");
define("LAN_EC_PM_06", "Start Massenverarbeitung PM für [y] Empfänger");
