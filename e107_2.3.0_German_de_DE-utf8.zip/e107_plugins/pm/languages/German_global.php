<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/pm/languages/German_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/10 08:29:09 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_PM_NAME", "Privates Nachrichtensytem");
define("LAN_PLUGIN_PM_DESCRIPTION", "Dieses Plugin ist ein voll ausgestattetes Privates Nachrichtensystem.");
define("LAN_PLUGIN_PM_URL_DEFAULT_LABEL", "Standard");
define("LAN_PLUGIN_PM_URL_DEFAULT_DESCR", "Standard");
define("LAN_PLUGIN_PM_INBOX", "Posteingang");
define("LAN_PLUGIN_PM_OUTBOX", "Postausgang");
define("LAN_PLUGIN_PM_NEW", "Senden eine neue Nachricht");
define("LAN_PLUGIN_PM_TO", "an");
define("LAN_PLUGIN_PM_FROM", "von");
define("LAN_PLUGIN_PM_SUB", "Betreff");
define("LAN_PLUGIN_PM_MESS", "Nachricht");
define("LAN_PLUGIN_PM_READ", "gelesen");
define("LAN_PLUGIN_PM_DEL", "PN löschen");
define("LAN_PLUGIN_PM_ATTACHMENT", "Anhang");
define("LAN_PLUGIN_PM_SIZE", "Größe");


?>