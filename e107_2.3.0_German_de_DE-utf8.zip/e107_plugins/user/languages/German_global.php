<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/01/24 18:55:11
|
|        $Author: yak $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_USER_NAME", "Benutzer");
define("LAN_PLUGIN_USER_DESC", "Benutzer Theme und Sprachenmenüs");


?>