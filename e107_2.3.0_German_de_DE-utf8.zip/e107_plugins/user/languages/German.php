<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UTHEME_MENU_L1", "Satz");
define("UTHEME_MENU_L2", "Sprache auswählen");
define("UTHEME_MENU_L3", "Tabellen");
define("LAN_UMENU_THEME_1", "Set-Theme");
define("LAN_UMENU_THEME_2", "Thema wählen");
define("LAN_UMENU_THEME_3", "Benutzer:");
define("LAN_UMENU_THEME_4", "Aktivieren Sie diese Themen, die Benutzer auswählen kann");
define("LAN_UMENU_THEME_5", "Update");
define("LAN_UMENU_THEME_6", "Themen, die den Benutzern zur Verfügung");
define("LAN_UMENU_THEME_7", "Klasse die Themen auswählen können");
define("LAN_UMENU_THEME_8", "Zulässige Themen:");
define("LAN_UMENU_THEME_9", "Klasse die Themen auswählen können:");
