<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("XMLRPC_ADMIN_001", "Hauptmenü");
define("XMLRPC_CONFIG_001", "MetaWeblog:: Konfiguration");
define("XMLRPC_PREFS_001", "eXMLRPC - Optionen");
define("XMLRPC_PREFS_002", "eXMLRPC");
define("XMLRPC_PREFS_003", "Neuigkeiten-Render-Typ (0,1,2,3)");
define("XMLRPC_PREFS_004", "Upload-Verzeichnis (E_FILE /)");
define("XMLRPC_PREFS_005", "Blog-ID für den client");
define("XMLRPC_PREFS_006", "Blog-Name für client");
define("XMLRPC_HELP_001", "Anweisungen");
define("XMLRPC_HELP_010", "Allgemeine");
define("XMLRPC_HELP_011", "Dieses Plugin selbst tut nichts! Es ist nur für Einstellungen einige XMLRPC-Variablen. Verweisen Sie Ihren XMLRPC Client (zB: Windows Live Writer) zu <strong>'. SITEURL.' MetaWeblog.php</strong> und füllen Sie die angeforderten Werte. Warnung! Dieses Plugin ist noch experimentell!");
define("XMLRPC_HELP_020", "Plugin-Titel");
define("XMLRPC_HELP_021", "Egal Plugin nicht ausgeben");
define("XMLRPC_HELP_030", "Neuigkeiten-Render-Typ");
define("XMLRPC_HELP_031", "Wichtig! Standard-Nachrichten-Render-Typ");
define("XMLRPC_HELP_040", "Ordner für Dateien hochladen");
define("XMLRPC_HELP_041", "Es ist immer ein Ordner 'e107_files'!");
define("XMLRPC_HELP_050", "Blog-ID für den client");
define("XMLRPC_HELP_051", "Blog-Id für XMLRPC Client (beliebige Zeichenfolge gewünschte)");
define("XMLRPC_HELP_060", "Blog-Name für client");
define("XMLRPC_HELP_061", "Blog-Name für XMLRPC Client (beliebige Zeichenfolge gewünschte)");
