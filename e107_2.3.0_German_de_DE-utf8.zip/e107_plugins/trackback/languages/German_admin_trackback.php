<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|
+----------------------------------------------------------------------------+
*/
define("TRACKBACK_L7", "Verfolgung aktivieren");
define("TRACKBACK_L8", "Verfolgungs URL Text");
define("TRACKBACK_L10", "Verfolgungs Einstellungen");
define("TRACKBACK_L11", "Verfolgungs Adresse für diesen Eintrag:");
define("TRACKBACK_L12", "Keine Verfolgung  für diesen Eintrag");
define("TRACKBACK_L13", "Verfolgung moderieren");
define("TRACKBACK_L16", "Verfolgungen");


?>