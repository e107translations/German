<?php

define("LAN_PLUGIN_TRACKBACK_NAME", "Trackback");
define("LAN_PLUGIN_TRACKBACK_DESCRIPTION", "Dieses Plugin erlaubt Ihnen Trackback in Ihren Newsposts zu verwenden.");

?>