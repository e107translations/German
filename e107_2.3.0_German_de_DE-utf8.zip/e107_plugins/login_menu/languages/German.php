<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 *
 *
 * $Source: /cvs_backup/e107_0.8/e107_plugins/login_menu/languages/English.php,v $
 * $Revision$
 * $Date$
 * $Author$
 */
define("LAN_LOGINMENU_1", "Benutzername:");
define("LAN_LOGINMENU_2", "Passwort:");
define("LAN_LOGINMENU_3", "Registrieren");
define("LAN_LOGINMENU_4", "Passwort vergessen?");
define("LAN_LOGINMENU_5", "Willkommen");
define("LAN_LOGINMENU_6", "Erinnere mich");
define("LAN_LOGINMENU_7", "Eindeutige Benutzer-ID nicht erkannt (mögliches beschädigtes Cookie). Bitte klicken Sie unten auf den Abmelde-Link, um Cookie zu zerstören");
define("LAN_LOGINMENU_9", "Anmeldefehler");
define("LAN_LOGINMENU_10", "Die Wartungs-Flag ist wahr - das bedeutet, dass normale Besucher auf sitedown.php umgeleitet werden.Um das Flag zurückzusetzen gehe zur Admin / Verwaltung .");
define("LAN_LOGINMENU_11", "Adminbereich");
define("LAN_LOGINMENU_13", "Profil");
define("LAN_LOGINMENU_14", "News Eintrag");
define("LAN_LOGINMENU_15", "News Einträge");
define("LAN_LOGINMENU_16", "Chatbox Eintrag");
define("LAN_LOGINMENU_17", "Chatbox Einträge");
define("LAN_LOGINMENU_18", "Kommentar");
define("LAN_LOGINMENU_19", "Kommentare");
define("LAN_LOGINMENU_20", "Forumeintrag");
define("LAN_LOGINMENU_21", "Forumeinträge");
define("LAN_LOGINMENU_22", "Neues Website-Mitglied");
define("LAN_LOGINMENU_23", "Neue Website-Mitglieder");
define("LAN_LOGINMENU_24", "Klicken Sie hier, um die Liste der neuen Artikel zu sehen");
define("LAN_LOGINMENU_25", "Seit deinen letzten Besuch waren da");
define("LAN_LOGINMENU_26", "Nein");
define("LAN_LOGINMENU_27", "und");
define("LAN_LOGINMENU_31", "Neue Nachrichten anzeigen");
define("LAN_LOGINMENU_34", "Neue Kommentar Beiträge anzeigen");
define("LAN_LOGINMENU_36", "Zeige neue Mitglieder");
define("LAN_LOGINMENU_39", "Admin Genehmigung");
define("LAN_LOGINMENU_40", "Aktivierungs - E-Mail erneut senden.");
define("LAN_LOGINMENU_41", "Anmeldemenü Einstellungen");
define("LAN_LOGINMENU_37", "anzeigen");
define("LAN_LOGINMENU_38", "Anmeldemenü - Weitere Links");
define("LAN_LOGINMENU_42", "Anmeldemenü - Neuere Kernzusätze");
define("LAN_LOGINMENU_43", "Position");
define("LAN_LOGINMENU_44", "Fehlende Link-Titel");
define("LAN_LOGINMENU_45", "Link(s) -");
define("LAN_LOGINMENU_45a", "");
define("LAN_LOGINMENU_45b", "Plugin");
define("LAN_LOGINMENU_46", "letzte Artikel -");
define("LAN_LOGINMENU_47", "Anmeldemenü - Neueste Plugin-Ergänzungen");
define("LAN_LOGINMENU_48", "Menü Konfig");
define("LAN_LOGINMENU_49", "Email:");
define("LAN_LOGINMENU_50", "Benutzername oder Email:");
define("LAN_LOGINMENU_51", "Anmelden");


?>