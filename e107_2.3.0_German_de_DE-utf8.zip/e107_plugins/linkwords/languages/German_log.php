<?php

 
// Admin log related
define("LAN_AL_LINKWD_00", "Linkword-related message");
define("LAN_AL_LINKWD_01", "Linkword Added");
define("LAN_AL_LINKWD_02", "Linkword Edited");
define("LAN_AL_LINKWD_03", "Linkword deleted");
define("LAN_AL_LINKWD_04", "Linkword options updated");
define("LAN_AL_LINKWD_05", "Linkwords version update");					// Used in 0.7-compatible stub only


?>