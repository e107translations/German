<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/03/12 15:20:58
|
|        $Author: Admin $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_LINKWORDS_NAME", "Linkwords");
define("LAN_PLUGIN_LINKWORDS_DESCRIPTION", "This plugin will link specified words with a defined link and/or tooltip.");


?>