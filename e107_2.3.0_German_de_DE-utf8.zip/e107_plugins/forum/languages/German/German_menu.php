<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/German/German_menu.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/06 03:01:43 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LAN_FORUM_MENU_001", "geschrieben von");
define("LAN_FORUM_MENU_002", "Keine neuen Einträge zurzeit");
define("LAN_FORUM_MENU_003", "Neue Beiträge Menükonfiguration gespeichert");
define("LAN_FORUM_MENU_004", "Überschrift");
define("LAN_FORUM_MENU_005", "Anzahl der Einträge zum anzeigen");
define("LAN_FORUM_MENU_006", "Anzahl der Schriftzeichen zum anzegeigen");
define("LAN_FORUM_MENU_007", "Postfix für zu lange Beiträge?");
define("LAN_FORUM_MENU_008", "zeige Originale Themen im Menü");
define("LAN_FORUM_MENU_009", "Menüeinstellungen aktualisiert");
define("LAN_FORUM_MENU_012", "Maximales Alter der angezeigten Beiträge");
define("LAN_FORUM_MENU_013", "Benutze 0 auf einer ruhigen Seite; Einstellen eines Wertes in Tagen wird die Datenbankzeit auf einer belebten Website reduzieren");
define("LAN_FORUM_MENU_014", "Scrolling Layer Höhe (in Pixel)");
define("LAN_FORUM_MENU_015", "Leer lassen für kein Scrollen");
define("LAN_FORUM_MENU_016", "Noch keine Forenkategorien erstellt!");
