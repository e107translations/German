<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/forum/languages/German/lan_forum_uploads.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_forum_uploads.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','Hochgeladene Dateien im Forum');
define('FRMUP_2','Datei gelöscht');
define('FRMUP_3','Fehler: Datei kann nicht gelöscht werden');
define('FRMUP_4','Datei Löschung');
define('FRMUP_5','Dateiname');
define('FRMUP_6','Ergebnis');
define('FRMUP_7','Im Thread gefunden');
define('FRMUP_8','NICHT GEFUNDEN');
define('FRMUP_9','Keine hochgeladenen Datein gefunden');
define('FRMUP_10','Löschen');
	
?>