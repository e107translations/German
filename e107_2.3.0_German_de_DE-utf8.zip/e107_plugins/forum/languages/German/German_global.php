<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/German/German_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/06 04:22:12 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_FORUM_NAME", "Forum");
define("LAN_PLUGIN_FORUM_DESC", "Dieses Plugin ist ein voll ausgestattetes Forensystem .");
define("LAN_PLUGIN_FORUM_POSTS", "Forum Beiträge");
define("LAN_PLUGIN_FORUM_ALLFORUMS", "Alle Foren");
define("LAN_PLUGIN_FORUM_LATESTPOSTS", "letzten Einträge");
define("FORUM_LAN_URL_DEFAULT_LABEL", "Standard Forum URLs");
define("FORUM_LAN_URL_DEFAULT_DESCR", "URLs von ' GET Typ ' ohne zentrale Anlaufstelle . Beispiele: <br /> http://ihreseite.com/e107_plugins/forum/forum.php (forum index) <br /> http://ihreseite.com/e107_plugins/forum/forum_viewtopic.php?id=2 (Thema Ansicht)");
define("FORUM_LAN_URL_REWRITE_LABEL", "SEF URLs Forum (in Entwicklung)");
define("FORUM_LAN_URL_REWRITE_DESCR", "Beispiel:<br/>(in Entwicklung)");


?>