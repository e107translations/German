<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/03/10 15:11:13
|
|        $Author: Admin $
+---------------------------------------------------------------+
*/

define("FORUM_LAN_URL_NAME", "Forum");
define("FORUM_LAN_URL_DEFAULT_LABEL", "Standard Forun URLs");
define("FORUM_LAN_URL_DEFAULT_DESCR", "URLs von ' GET Typ' mit keinem einzigen Eintrittspunkt . Beispiele: <br /> http://yoursite.com/e107_plugins/forum/forum.php ( Forum -Index) <br /> http://yoursite.com/e107_plugins/forum/forum_viewtopic.php?id=2 (Thema Ansicht)");
define("FORUM_LAN_URL_REWRITE_LABEL", "SEF Forum URLs(IN ENTWICKLUNG)");
define("FORUM_LAN_URL_REWRITE_DESCR", "Beispiele:<br/>(IN ENTWICKLUNG)");


?>