<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/download/languages/German/German_front.php $
|        $Revision: 1.0 $
|        $Id: 2015/06/30 17:16:18 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LAN_dl_1", "Eingeschränkt");
define("LAN_dl_4", "Erreichbare Dateien:");
define("LAN_dl_5", "Gesamtgröße der Dateien:");
define("LAN_dl_6", "Heruntergeldene Dateien:");
define("LAN_dl_8", "Erhalten");
define("LAN_dl_9", "Zurück zur Kategorieliste");
define("LAN_dl_13", "Keine Bewertet");
define("LAN_dl_14", "Bewerte diesen Download");
define("LAN_dl_16", "Download(s) von");
define("LAN_dl_29", "Downloads");
define("LAN_dl_30", "Autor Email");
define("LAN_dl_31", "Autor Webseite");
define("LAN_dl_36", "Neue Downloads");
define("LAN_dl_40", "Klicke hier für ein Screenshot");
define("LAN_dl_43", "Stimme");
define("LAN_dl_44", "Stimmen");
define("LAN_dl_45", "Defekten Download melden");
define("LAN_dl_46", "Klicke hier zum Download");
define("LAN_dl_47", "Beitrag wurde bereits gemeldet");
define("LAN_dl_48", "Download wurde dem Administrator gemeldet.<br />Vielen Dank.");
define("LAN_dl_49", "Klicke hier zum Download");
define("LAN_dl_53", "Klicken hier um die Downloads zu sehen");
define("LAN_dl_54", "Ein Administrator wird über diesen Download informiert werden, bitte hinterlassen Sie eine Nachricht, falls Sie es für wichtig erachten.");
define("LAN_dl_55", "<b>Bitte</b> dieses Formular nicht benutzen um den Administratoranderwetig zu kontaktieren.");
define("LAN_dl_62", "Du hast dein Downloadmaximum erreicht und es wurde deshalb verhindert, diese Datei downloaden zu können.");
define("LAN_dl_63", "Du hast keine Berechtigung diese Datei herunterzuladen.");
define("LAN_dl_66", "Download Mirror auswählen");
define("LAN_dl_67", "Mirror auswählen...");
define("LAN_dl_68", "Mirror Host");
define("LAN_dl_72", "Datei anfordern:");
define("LAN_dl_73", "Downloads von diesen Mirror:");
define("LAN_dl_74", "Gesamte Downloads von diesen Mirror:");
define("LAN_dl_75", "kein Bild vorhanden");
define("LAN_dl_77", "Downloads");
define("LAN_dl_78", "Dieser Download wurde deaktiviert oder steht nicht mehr zur Verfügung. Bitte schaue unter [link=--LINK--]downloads area[/link] nach einer neueren Version.");
define("LAN_dl_79", "Sie verfügen nicht über die richtigen Berechtigungen, um dieses Downloadelement als fehlerhaft zu melden.");
