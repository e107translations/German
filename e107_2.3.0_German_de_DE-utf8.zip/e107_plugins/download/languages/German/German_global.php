<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2020/05/16 08:33:31
|
|        $Author: LazyTitan $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_DOWNLOAD_NAME", "Downloads");
define("LAN_PLUGIN_DOWNLOAD_DIZ", "This plugin is a fully featured File-download system");
define("LAN_DL_NT_01", "Download wird als defekt gemeldet");
define("LAN_DL_NT_02", "Der folgende Download wurde als defekt gemeldet:");
define("LAN_DL_NT_03", "Es wurde von [x] mit der folgenden Nachricht gemeldet:");
define("LAN_DL_NT_04", "Klicken Sie auf [hier], um die fehlerhaften Downloadberichte anzuzeigen.");
define("LAN_DL_LATEST_01", "Gemeldete fehlerhafte Downloads");
