<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/09/24 15:44:47
|
|        $Author: Killer0561 $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_CHATBOX_MENU_NAME", "Chatbox");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", "Chatbox Menu");
define("LAN_PLUGIN_CHATBOX_MENU_POSTS", "Chatbox Beiträge");
define("LAN_AL_CHBLAN_01", "Chatbox Einstellungen aktualisiert");
define("LAN_AL_CHBLAN_02", "Chatbox gekürzt");
define("LAN_AL_CHBLAN_03", "Chatbox Beiträge neu berechnet");
define("LAN_AL_CHBLAN_04", "");
define("LAN_AL_CHBLAN_05", "");
define("NT_LAN_CB_1", "Chatbox Veranstaltungen");
define("NT_LAN_CB_2", "Nachricht gepostet");
define("NT_LAN_CB_3", "Geschrieben von");
define("NT_LAN_CB_5", "Nachricht");
define("NT_LAN_CB_6", "Chatbox Nachricht geschrieben");


?>