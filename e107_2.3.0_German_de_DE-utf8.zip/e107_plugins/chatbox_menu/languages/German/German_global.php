<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/chatbox_menu/languages/German/German_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/07 23:04:16 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_CHATBOX_MENU_NAME", "Chatbox");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", "Chatbox Menü");
define("LAN_PLUGIN_CHATBOX_MENU_POSTS", "Chatbox Einträge");
define("LAN_AL_CHBLAN_01", "Chatbox Einstellungen wurden aktualisiert");
define("LAN_AL_CHBLAN_02", "Chatbox Pruned.");
define("LAN_AL_CHBLAN_03", "Chatbox Beiträge neu berechnet");
define("LAN_AL_CHBLAN_04", "");
define("LAN_AL_CHBLAN_05", "");
define("NT_LAN_CB_1", "Chatbox Ereignisse");
define("NT_LAN_CB_2", "Nachricht geschrieben");
define("NT_LAN_CB_3", "Geschrieben von");
define("NT_LAN_CB_5", "Nachricht");
define("NT_LAN_CB_6", "Chatbox Nachricht geschrieben");


?>