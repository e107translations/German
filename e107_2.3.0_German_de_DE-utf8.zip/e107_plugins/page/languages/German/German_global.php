<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/03/10 16:41:22
|
|        $Author: Admin $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_PAGE_BOCHAP", "suchen in Buch/Kapitel");
define("LAN_PLUGIN_PAGE_NAME", "Seiten");
