<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/12/03 14:48:09
|
|        $Author: yak $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_RSS_NAME", "RSS");
define("LAN_PLUGIN_RSS_DESCRIPTION", "RSS Feeds von deiner Seite.");
define("LAN_PLUGIN_RSS_SUBSCRIBE", "abonnieren");
define("LAN_PLUGIN_RSS_SUBSCRIBE_TO", "abonnieren nach [x]");


?>