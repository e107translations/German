<?php

define("EXAMPLE","Generated Empty Language File");