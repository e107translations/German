<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/09/16 14:51:37
|
|        $Author: Yak $
+---------------------------------------------------------------+
*/

define("BANNERLAN_16", "Benutzername:");
define("BANNERLAN_17", "Passwort:");
define("BANNERLAN_19", "Bitte geben Sie Ihr Kundenlogin und Passwort weiter");
define("BANNERLAN_20", "Entschuldigung, konnte nicht diese Informationen in der Datenbank finden. Bitte kontaktieren Sie den Webseitenadministrator für Details.");
define("BANNERLAN_21", "Banner-Statistik");
define("BANNERLAN_22", "Kunde");
define("BANNERLAN_23", "Banner-ID");
define("BANNERLAN_24", "Klicks durch");
define("BANNERLAN_25", "Klick  %");
define("BANNERLAN_26", "Impressionen");
define("BANNERLAN_27", "Impressionen gekauft");
define("BANNERLAN_28", "Impressionen Links");
define("BANNERLAN_29", "Keine Banner");
define("BANNERLAN_30", "Unbegrenzt");
define("BANNERLAN_31", "Nicht zutreffend");
define("BANNERLAN_34", "Endet:");
define("BANNERLAN_35", "Klick durch IP Adressen");
define("BANNERLAN_36", "Aktiv:");
define("BANNERLAN_37", "Beginnt:");
define("BANNERLAN_39", "Kein Bild für diesen Banner zugewiesen.");


?>