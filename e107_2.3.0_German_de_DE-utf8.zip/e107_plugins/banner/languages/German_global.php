<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/banner/languages/German_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/07 23:00:01 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_BANNER_NAME", "Werbebanner");
define("LAN_PLUGIN_BANNER_DESCRIPTION", "Werbebanner auf Ihre Webseite hinzufügen");


?>