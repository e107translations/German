<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/03/12 15:16:36
|
|        $Author: Admin $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Werbebanner");
define("BANNERLAN_16", "Benutzername");
define("BANNERLAN_17", "Passwort");
define("BANNERLAN_19", "Bitte geben Sie Ihre Kunden-Login und Passwort ein, um fortzufahren");
define("BANNERLAN_20", "Entschuldigung, konnte diese Informationen in der Datenbank nicht finden. Bitte kontaktieren Sie den Webseiten-Administrator.");
define("BANNERLAN_21", "Banner Statistik");
define("BANNERLAN_22", "Kunde");
define("BANNERLAN_23", "Banner ID");
define("BANNERLAN_24", "Klick durch");
define("BANNERLAN_25", "Klick %");
define("BANNERLAN_26", "Eindrücke");
define("BANNERLAN_27", "Eindrücke gekauft");
define("BANNERLAN_28", "Eindrücke übrig");
define("BANNERLAN_29", "Keine Banner");
define("BANNERLAN_30", "unbegrenzt");
define("BANNERLAN_31", "Nicht anwendbar");
define("BANNERLAN_34", "endet:");
define("BANNERLAN_35", "Klick durch IP Adressen");
define("BANNERLAN_36", "Aktiv");
define("BANNERLAN_37", "startet:");


?>