<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * List Language
 *
|     $Source: /cvs_backup/e107_0.8/e107_plugins/list_new/languages/English.php,v $
|     $Revision$
|     $Date$
|     $Author$
 *
*/
define("LIST_MENU_1", "recent additions");
define("LIST_MENU_2", "von");
define("LIST_MENU_3", "am");
define("LIST_MENU_4", "in");
define("LIST_MENU_5", "Tage");
define("LIST_MENU_6", "Für wieviele Tage sollen Einträge angezeigt werden?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");
define("LIST_NEWS_1", "News");
define("LIST_NEWS_2", "Keine Newseinträge");
define("LIST_COMMENT_1", "Kommentare");
define("LIST_COMMENT_2", "Keine Kommentare");
define("LIST_COMMENT_3", "News");
define("LIST_COMMENT_4", "FAQ");
define("LIST_COMMENT_5", "Umfrage");
define("LIST_COMMENT_6", "Doks");
define("LIST_COMMENT_7", "Bugtracker");
define("LIST_COMMENT_8", "Inhalt");
define("LIST_COMMENT_9", "");
define("LIST_COMMENT_10", "Ideen");
define("LIST_MEMBER_1", "Mitglieder");
define("LIST_MEMBER_2", "Keine Mitglieder");
define("LIST_CONTENT_1", "Inhalt");
define("LIST_CONTENT_2", "Keine Inhalte in");
define("LIST_CONTENT_3", "Keine gültige Inhaltkategorie");
define("LIST_CHATBOX_1", "Chatbox");
define("LIST_CHATBOX_2", "Keine Chatbox Einträge");
define("LIST_CALENDAR_1", "Kalender");
define("LIST_CALENDAR_2", "Keine Kalenderevents");
define("LIST_LINKS_1", "Links");
define("LIST_LINKS_2", "Keine Links");
define("LIST_FORUM_1", "Forum");
define("LIST_FORUM_2", "Keine Foreneinträge");
define("LIST_FORUM_3", "Ansichten:");
define("LIST_FORUM_4", "Antworten:");
define("LIST_FORUM_5", "Letzte Einträge:");
define("LIST_FORUM_6", "am:");
define("LIST_LAN_1", "Keine Artikel in");
define("LIST_DOWNLOAD_1", "Downloads");
define("LIST_DOWNLOAD_2", "Keine Downloads");


?>