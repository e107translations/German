<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/12/01 13:11:25
|
|        $Author: Killer0561 $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_LIST_NEW_NAME", "Neue Artikel auflisten");
define("LAN_PLUGIN_LIST_NEW_DESCRIPTION", "Mit diesem Plugin können Sie eine Liste und/oder ein Menü mit den neuesten Ergänzungen in allen e107 Kategorien anzeigen. Sie können entweder die Liste mit Daten seit Ihrem letzten Besuch anzeigen oder eine allgemeine Liste der neuesten Ergänzungen anzeigen.");
