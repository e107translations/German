<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/05/01 18:40:07
|
|        $Author: yak $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_TAGCLOUD_NAME", "Tag Cloud");
define("LAN_PLUGIN_TAGCLOUD_DESCRIPTION", "Ein einfaches Tagcloud Menü für ihre e107 Webseite");


?>