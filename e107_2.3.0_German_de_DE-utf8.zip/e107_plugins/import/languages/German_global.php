<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_IMPORT_NAME", "E107 importieren");
define("LAN_PLUGIN_IMPORT_DESCRIPTION", "Importieren von Daten aus Wordpress, Joomla, Drupal, Blogpost, RSS und andere Formate.");
