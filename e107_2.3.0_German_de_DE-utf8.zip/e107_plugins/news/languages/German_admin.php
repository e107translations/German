<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/06 13:46:17
|
|        $Author: yak $
+---------------------------------------------------------------+
*/

define("LAN_NEWS_ADMIN_00", "Aktuelle Nachrichten");
define("LAN_NEWS_ADMIN_01", "Wichtige Nachrichten");
define("LAN_NEWS_ADMIN_02", "Zugeordnete Nachrichten");
define("LAN_NEWS_ADMIN_03", "Begrenzung von Nachrichten auf eine bestimmte Kategorie");
define("LAN_NEWS_ADMIN_04", "Zugeordnete Nachrichten sind  mit einer Vorlage zugeordnet 'Nachrichten Rastermenü'");
define("LAN_NEWS_ADMIN_05", "Anzahl der anzuzeigenden Artikel");
define("LAN_NEWS_ADMIN_06", "Titel Zeichengrenze");
define("LAN_NEWS_ADMIN_07", "Zusammenfassung der Zeichenbegrenzung");
define("LAN_NEWS_ADMIN_08", "Archiv Link anzeigen");
define("LAN_NEWS_ADMIN_09", "Begrenzungen");
define("LAN_NEWS_ADMIN_10", "Anzahl der Artikelmerkmale");
define("LAN_NEWS_ADMIN_11", "Zugeordnete Elemente die mit einer Vorlage zugeordnet 'Nachrichten Karussell'");


?>