<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/news/languages/German.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/09 06:41:36 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("TD_MENU_L1", "News/sonstiges");
define("TD_MENU_L2", "weitere News");
define("LAN_NEWSCAT_MENU_TITLE", "News Kategorien");
define("LAN_NEWSLATEST_MENU_TITLE", "letzten News");
define("LAN_NEWSARCHIVE_MENU_TITLE", "News Archiv");
