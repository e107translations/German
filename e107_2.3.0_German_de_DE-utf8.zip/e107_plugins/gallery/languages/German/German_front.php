<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 12:18:12
|
|        $Author: Admin $
+---------------------------------------------------------------+
*/
define("LAN_GALLERY_FRONT_01", "Mit Rechtsklick > Ziel speichern unter");
define("LAN_GALLERY_FRONT_02", "Erweitern Sie das Bild");


?>