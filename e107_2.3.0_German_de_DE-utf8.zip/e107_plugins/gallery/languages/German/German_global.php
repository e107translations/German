<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/gallery/languages/German/German_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/07/05 21:03:01 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_GALLERY_TITLE", "Galerie");
define("LAN_PLUGIN_GALLERY_DIZ", "Eine einfache Bildgalerie");
define("LAN_PLUGIN_GALLERY_SEF_01", "Galerie SEF");
define("LAN_PLUGIN_GALLERY_SEF_02", "SEF URLs aktiviert.");
define("LAN_PLUGIN_GALLERY_SEF_03", "SEF URLs deaktiviert");
define("LAN_PLUGIN_GALLERY_SEF_04", "Galerie Standard");


?>