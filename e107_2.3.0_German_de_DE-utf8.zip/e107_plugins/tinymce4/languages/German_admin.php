<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/10 18:22:27
|
|        $Author: yak $
+---------------------------------------------------------------+
*/
define("TMCEALAN_1", "Füge den Text standardmäßig ein");
define("TMCEALAN_2", "Browser Rechtschreibprüfung");
define("TMCEALAN_3", "Aktiviere dies, wenn im internen Browser Rechtschreibprüfung verwendet werden soll.");
define("TMCEALAN_4", "Visuelle Funktionsblöcke");
define("TMCEALAN_5", "Aktivieren um HTML Funktionsblöcke während der Bearbeitung sichtbar zu machen.");
define("TMCEALAN_6", "Code-Highlight CSS class.");
